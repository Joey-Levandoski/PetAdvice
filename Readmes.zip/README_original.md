# PetAdvice — iOS App (Swift / SwiftUI)

Converted from original Java/Swing assignment (2016) to Swift 5 + SwiftUI.

---

## Original Java → Swift Mapping

| Java Concept | Swift Equivalent |
|---|---|
| `main(String[] args)` | `PetAdviceApp.swift` (`@main`) |
| `JOptionPane.showInputDialog` | SwiftUI `Picker` + `TextField` |
| `JOptionPane.showMessageDialog` | SwiftUI result card + `.alert` |
| `getPet(double, int)` | `PetAdvisor.recommend(hoursAtHome:housing:)` |
| `switch` on housing int | `switch` on `HousingType` enum |
| `System.exit(1)` | `.alert` with error message |

---

## Project Structure

```
PetAdvice/
└── PetAdvice/
    ├── PetAdviceApp.swift   # App entry point (@main)
    ├── ContentView.swift    # SwiftUI UI — form + result display
    └── PetAdvisor.swift     # Business logic (pet recommendation engine)
```

---

## How to Run

1. Open **Xcode** (version 15+ recommended).
2. Create a new **iOS App** project in Xcode:
   - Product Name: `PetAdvice`
   - Interface: `SwiftUI`
   - Language: `Swift`
3. Replace the generated files with the three `.swift` files in this project.
4. In Xcode's Asset Catalog (`Assets.xcassets`), add two color sets:
   - `BackgroundTop` — e.g. a soft light blue or white
   - `BackgroundBottom` — e.g. a soft lavender or light gray
   *(Or remove the gradient from ContentView and use a plain background.)*
5. Select a simulator (e.g. iPhone 16) and press **Run (⌘R)**.

---

## Logic Notes

- The original Java code had a likely typo: `var0 == 10.0 && var0 <= 17.0` — the `==` was almost certainly meant to be `>=`. This has been corrected to `hoursAtHome >= 10` for the House/Dog case.
- All other branching logic is preserved exactly as written in the original.

---

## Pet Recommendation Logic (preserved from original)

| Housing | Hours at Home | Recommended Pet |
|---------|--------------|----------------|
| House | ≥ 18 hrs | Pot-Bellied Pig |
| House | 10–17 hrs | Dog |
| House | < 10 hrs | Snake |
| Apartment | ≥ 10 hrs | Cat |
| Apartment | < 10 hrs | Hamster |
| Dormitory | ≥ 6 hrs | Fish |
| Dormitory | < 6 hrs | Ant Farm |
