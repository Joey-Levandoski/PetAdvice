# PetAdvice — iOS App (Swift / SwiftUI)

Converted from original Java/Swing extra credit assignment (2016) to Swift 5 + SwiftUI.
Built and debugged through Xcode with a working simulator on iPhone 17 Pro.

---

## Original Java → Swift Mapping

| Java Concept | Swift Equivalent |
|---|---|
| `main(String[] args)` | `PetAdviceApp.swift` (`@main`) |
| `JOptionPane.showInputDialog` | SwiftUI `Picker` + `TextField` |
| `JOptionPane.showMessageDialog` | SwiftUI result card + `.alert` |
| `getPet(double, int)` | `petAdvisor.recommend(hoursAtHome:housing:)` |
| `switch` on housing int | `switch` on `HousingType` enum |
| `System.exit(1)` | `.alert` with error message |

---

## Project Structure

```
PetAdvice/
└── PetAdvice/
    ├── PetAdviceApp.swift   # App entry point (@main)
    ├── ContentView.swift    # SwiftUI UI — form + result display
    └── PetAdvisor.swift     # Business logic (pet recommendation engine)
```

---

## How to Run

1. Open **Xcode** (version 15+ recommended).
2. Create a new **iOS App** project in Xcode:
   - Product Name: `PetAdvice`
   - Organization Identifier: `com.yourname` (required — leaving this blank disables the Next button)
   - Interface: `SwiftUI`
   - Language: `Swift`
3. In the Project Navigator sidebar, replace the contents of the auto-generated files:
   - Paste the new code into `ContentView.swift` and `PetAdviceApp.swift`
   - Create a new Swift file named `PetAdvisor` and paste in that code
4. Make sure all 3 files have **Target Membership** checked for `PetAdvice` in the File Inspector
5. Use `Color(.systemBackground).ignoresSafeArea()` for the background — no custom color assets needed
6. Select a simulator (e.g. iPhone 17 Pro) and press **Run (⌘R)**
7. **Leave the simulator open** between runs — relaunch with ⌘R each time rather than closing it

---

## Bugs Fixed During Development

| Bug | Cause | Fix |
|-----|-------|-----|
| Next button grayed out in Xcode | Organization Identifier was blank | Added `com.yourname` format |
| `Undefined symbol: _main` | `@main` missing or in wrong file | Moved `@main` exclusively to `PetAdviceApp.swift` |
| `Cannot find 'ContentView' in scope` | Wrong code pasted into `ContentView.swift` | Replaced with correct `ContentView` code |
| `Cannot find 'PetAdvisor' in scope` | Struct named `petAdvisor` (lowercase) but referenced as `PetAdvisor` | Standardized reference in `ContentView.swift` to `petAdvisor` |
| `Cannot find 'HousingType' in scope` | Enum named `housingType` (lowercase) but referenced as `HousingType` | Renamed enum to `HousingType` (uppercase) |
| Blank white screen in simulator | Custom gradient colors `BackgroundTop`/`BackgroundBottom` never added to Assets | Replaced gradient with `Color(.systemBackground)` |
| App icon too large | Original photo was 4032x3024px | Cropped to square and resized to 1024x1024px |

---

## Naming Convention Notes

Due to the conversion from Java (camelCase) to Swift, the following naming decisions were made:

- `enum HousingType` — PascalCase (required by Swift for types)
- `struct petAdvisor` — lowercase retained from Java conversion (working as-is)
- All method names follow standard Swift camelCase

---

## Logic Notes

- The original Java code had a likely typo: `var0 == 10.0 && var0 <= 17.0` — the `==` was almost certainly meant to be `>=`. This has been corrected to `hoursAtHome >= 10` for the House/Dog case.
- All other branching logic is preserved exactly as written in the original.

---

## Pet Recommendation Logic (preserved from original)

| Housing | Hours at Home | Recommended Pet |
|---------|--------------|----------------|
| House | ≥ 18 hrs | Pot-Bellied Pig |
| House | 10–17 hrs | Dog |
| House | < 10 hrs | Snake |
| Apartment | ≥ 10 hrs | Cat |
| Apartment | < 10 hrs | Hamster |
| Dormitory | ≥ 6 hrs | Fish |
| Dormitory | < 6 hrs | Ant Farm |

---

## Simulator Tips

- **⌘R** — Build and run
- **⌘B** — Build only
- **⌘.** — Stop the app
- Always leave the simulator open in the background — closing it forces a full reboot on next run
